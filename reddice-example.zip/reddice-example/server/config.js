export default {
  jwtSecret: 'somesecretkeyforjsonwebtoken'
}
