import React from 'react';

class Greetings extends React.Component {
  render() {
    return (
      <div className="jumbotron">
        <h1>Hi!</h1>
      </div>
    );
  }
}

export default Greetings;
